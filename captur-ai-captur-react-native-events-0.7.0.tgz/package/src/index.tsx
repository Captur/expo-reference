import {
  NativeModules,
  NativeEventEmitter,
  requireNativeComponent,
  type HostComponent,
  UIManager,
  Platform,
  type ViewStyle,
  type EventSubscription,
} from 'react-native';

export type CapturDecision =
  | 'goodDelivery'
  | 'improvableDelivery'
  | 'badDelivery'
  | 'insufficientInformation'
  | 'noDecisionMapDetected';

export type CapturCameraState =
  | 'cameraRunning'
  | 'cameraDecided'
  | 'cameraError';

export interface CapturOutput {
  decision: CapturDecision;
  reason: string;
  guidanceTitle: string | undefined;
  guidanceDetail: string | undefined;
  decisionTitle: string | undefined;
  decisionDetail: string | undefined;
  imageDataBase64: string | undefined;
}

export type CapturErrorType =
  | 'locationNameEmpty'
  | 'modelInitialisationFailure'
  | 'modelUnavailable'
  | 'serialisationError'
  | 'modelVerificationFailed'
  | 'serverError'
  | 'videoDeviceNotFound'
  | 'videoDeviceInputError'
  | 'videoDeviceOutputError'
  | 'videoDeviceLockError'
  | 'modelDoesNotExistOnDevice'
  | 'unknownError';

export interface CapturError {
  errorType: CapturErrorType;
  errorMessage: string;
}

export enum CapturEventHandlerType {
  capturDidGenerateEvent = 'capturDidGenerateEvent',
  capturDidGenerateError = 'capturDidGenerateError',
  capturDidGenerateGuidance = 'capturDidGenerateGuidance',
  capturDidRevokeGuidance = 'capturDidRevokeGuidance',
}

export interface CapturEventsHandler {
  capturDidGenerateEvent: (
    capturCameraState: CapturCameraState,
    metadata: CapturOutput | undefined
  ) => void;
  capturDidGenerateError: (capturError: CapturError) => void;
  capturDidGenerateGuidance: (metadata: CapturOutput) => void;
  capturDidRevokeGuidance: () => void;
}

const LINKING_ERROR =
  `The package 'captur-react-native-events' doesn't seem to be linked. Make sure: \n\n` +
  Platform.select({ ios: "- You have run 'pod install'\n", default: '' }) +
  '- You rebuilt the app after installing the package\n' +
  '- You are not using Expo Go\n';

const CapturReactNativeEvents = NativeModules.CapturReactNativeEvents
  ? NativeModules.CapturReactNativeEvents
  : new Proxy(
      {},
      {
        get() {
          throw new Error(LINKING_ERROR);
        },
      }
    );

const CapturReactNativeEventsEmitter = new NativeEventEmitter(
  CapturReactNativeEvents
);

export function subscribeToEvents(
  capturEventsHandler: CapturEventsHandler
): () => void {
  const subscriptions: EventSubscription[] = [];
  subscriptions.push(
    CapturReactNativeEventsEmitter.addListener(
      CapturEventHandlerType.capturDidGenerateEvent,
      (event: { state: CapturCameraState; metadata?: CapturOutput }) => {
        capturEventsHandler.capturDidGenerateEvent(event.state, event.metadata);
      }
    )
  );

  subscriptions.push(
    CapturReactNativeEventsEmitter.addListener(
      CapturEventHandlerType.capturDidGenerateError,
      (error: CapturError) => {
        capturEventsHandler.capturDidGenerateError(error);
      }
    )
  );

  subscriptions.push(
    CapturReactNativeEventsEmitter.addListener(
      CapturEventHandlerType.capturDidGenerateGuidance,
      (metadata: CapturOutput) => {
        capturEventsHandler.capturDidGenerateGuidance(metadata);
      }
    )
  );

  subscriptions.push(
    CapturReactNativeEventsEmitter.addListener(
      CapturEventHandlerType.capturDidRevokeGuidance,
      () => {
        capturEventsHandler.capturDidRevokeGuidance();
      }
    )
  );

  return () => {
    for (const subscription of subscriptions) {
      subscription.remove();
    }
  };
}

export function endAttempt() {
  return CapturReactNativeEvents.endAttempt();
}

export function retake() {
  return CapturReactNativeEvents.retake();
}

export function setDelay(delay: number): Promise<boolean> {
  return CapturReactNativeEvents.setDelay(delay);
}

export function setTimeout(timeout: number): Promise<boolean> {
  return CapturReactNativeEvents.setTimeout(timeout);
}

export function setApiKey(apiKey: string, baseURL: string | null = null): Promise<boolean> {
  return CapturReactNativeEvents.setApiKey(apiKey, baseURL);
}

export function prepareModel(
  locationName: string,
  assetType: string,
  latitude: number,
  longitude: number
): Promise<boolean> {
  return CapturReactNativeEvents.prepareModel(
    locationName,
    assetType,
    latitude,
    longitude
  );
}

export function getConfig(
  locationName: string,
  assetType: string,
  latitude: number,
  longitude: number
): Promise<boolean> {
  return CapturReactNativeEvents.getConfig(
    locationName,
    assetType,
    latitude,
    longitude
  );
}

type CapturCameraViewProps = {
  style: ViewStyle;
  referenceId: string;
  isFlashOn: boolean;
  isZoomedIn: boolean;
  startVerification: boolean;
};

const ComponentName = 'CapturCameraView';

export const CapturCameraView: HostComponent<CapturCameraViewProps> =
  _CapturCameraView();

function _CapturCameraView() {
  if (UIManager.getViewManagerConfig(ComponentName) == null) {
    throw new Error(LINKING_ERROR);
  }

  return requireNativeComponent<CapturCameraViewProps>(ComponentName);
}
