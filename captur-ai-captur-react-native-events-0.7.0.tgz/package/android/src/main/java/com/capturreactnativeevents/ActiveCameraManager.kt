package com.capturreactnativeevents

import com.captur.capturmicromobility.pblic.CapturCameraManager

/**
 * Maintains a single reference to the active camera manager instance.
 */
object ActiveCameraManager {
  var instance: CapturCameraManager? = null
}
