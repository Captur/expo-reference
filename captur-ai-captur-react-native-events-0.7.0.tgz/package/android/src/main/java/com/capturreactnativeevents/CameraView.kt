package com.capturreactnativeevents

import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.captur.capturmicromobility.camera.CapturCameraPreview
import com.captur.capturmicromobility.pblic.CapturCameraManager
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun CameraView(
  reactContext: com.facebook.react.uimanager.ThemedReactContext,
  flashOn: Boolean,
  isZoomedIn: Boolean,
  startVerification: Boolean,
  referenceId: String,
) {

  // camera permission
  val cameraPermissionState = rememberPermissionState(Manifest.permission.CAMERA)
  val cameraManagerState = remember { mutableStateOf<CapturCameraManager?>(null) }

  LaunchedEffect(startVerification) {
    if (startVerification && !cameraPermissionState.status.isGranted) {
      cameraPermissionState.launchPermissionRequest()
    }

    if(!startVerification){
      cameraManagerState.value = null
      ActiveCameraManager.instance = null
    }
  }


  Box(modifier = Modifier.background(Color.Black)) {
    if (!startVerification) {
      Text("Camera NOT ACTIVE", color = Color.White)
      return@Box
    }


    if (!cameraPermissionState.status.isGranted) {
      Text("Camera permission not granted", color = Color.White)
      return@Box
    }

    // Initialize the manager once
    if (cameraManagerState.value == null) {
      val mgr = CapturCameraManager(referenceId)
      mgr.subscribeToEvents(CapturEventListeners(reactContext))
      ActiveCameraManager.instance = mgr
      cameraManagerState.value = mgr
    }


    val cameraManager = cameraManagerState.value!!

    Text("Camera verification active")

    CapturCameraPreview(
      system       = cameraManager,
      flashLightOn = flashOn,
      zoomState    = isZoomedIn
    )
  }
}
