package com.capturreactnativeevents

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Holds mutable states for the CameraView composable.
 */
class CameraViewFields {
  var isFlashOn by mutableStateOf(false)
  var isZoomedIn by mutableStateOf(false)
  var referenceId by mutableStateOf("123456")
  var startVerification by mutableStateOf(false)
}
