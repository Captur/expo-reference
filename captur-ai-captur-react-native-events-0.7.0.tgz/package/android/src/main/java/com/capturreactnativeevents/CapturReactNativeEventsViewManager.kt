package com.capturreactnativeevents

import android.util.Log
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import com.facebook.react.uimanager.SimpleViewManager
import com.facebook.react.uimanager.ThemedReactContext
import com.facebook.react.uimanager.annotations.ReactProp
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import java.util.WeakHashMap

/**
 * React Native view manager that hosts our [CameraView] composable.
 */
class CapturReactNativeEventsViewManager : SimpleViewManager<ComposeView>() {
  private val flashStateMap = WeakHashMap<ComposeView, MutableState<Boolean>>()
  private val zoomedInStateMap = WeakHashMap<ComposeView, MutableState<Boolean>>()
  private val startVerificationStateMap = WeakHashMap<ComposeView, MutableState<Boolean>>()
  private val referenceIdStateMap = WeakHashMap<ComposeView, MutableState<String>>()

  override fun getName() = "CapturCameraView"

  override fun createViewInstance(reactContext: ThemedReactContext): ComposeView {
    val flashState = mutableStateOf(false)
    val zoomedInState = mutableStateOf(false)
    val startVerificationState = mutableStateOf(false)
    val referenceIdState = mutableStateOf("123456")


    val composeView = ComposeView(reactContext).apply {
      setViewCompositionStrategy(
        ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed
      )
      setContent {
        CameraView(
          reactContext       = reactContext,
          flashOn            = flashState.value,
          isZoomedIn         = zoomedInState.value,
          startVerification  = startVerificationState.value,
          referenceId        = referenceIdState.value
        )
      }
    }
    flashStateMap[composeView]              = flashState
    zoomedInStateMap[composeView]           = zoomedInState
    startVerificationStateMap[composeView]  = startVerificationState
    referenceIdStateMap[composeView]  = referenceIdState
    return composeView
  }

  @ReactProp(name = "isFlashOn", defaultBoolean = false)
  fun isFlashOn(view: ComposeView, flashOn: Boolean) {
    Log.d("CapturViewManager", "isFlashOn → $flashOn")
    flashStateMap[view]?.value = flashOn
  }

  @ReactProp(name = "isZoomedIn", defaultBoolean = false)
  fun isZoomedIn(view: ComposeView, isZoomedIn: Boolean) {
    Log.d("CapturViewManager", "isZoomedIn → $isZoomedIn")
    zoomedInStateMap[view]?.value = isZoomedIn
  }

  @ReactProp(name = "startVerification", defaultBoolean = false)
  fun startVerification(view: ComposeView, startVerification: Boolean) {
    Log.d("CapturViewManager", "startVerification → $startVerification")
    startVerificationStateMap[view]?.value = startVerification
  }

  @ReactProp(name = "referenceId")
  fun setReferenceId(view: ComposeView, referenceId: String) {
    Log.d("CapturViewManager", "referenceId → $referenceId")
    referenceIdStateMap[view]?.value = referenceId
  }
}
