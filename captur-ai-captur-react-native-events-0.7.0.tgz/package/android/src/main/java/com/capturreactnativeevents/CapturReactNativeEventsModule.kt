package com.capturreactnativeevents

import com.captur.capturmicromobility.pblic.Captur
import com.captur.capturmicromobility.pblic.error.CapturError
import com.captur.capturmicromobility.pblic.events.CapturEvents
import com.captur.capturmicromobility.pblic.models.CapturAssetType
import com.captur.capturmicromobility.pblic.models.CapturCameraState
import com.captur.capturmicromobility.pblic.models.CapturOutput
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.modules.core.DeviceEventManagerModule

class CapturReactNativeEventsModule(
  private val reactContext: ReactApplicationContext
) : ReactContextBaseJavaModule(reactContext), CapturEvents {

  override fun canOverrideExistingModule() = true

  override fun getName() = "CapturReactNativeEvents"

  private var listenerCount = 0
  private var hasListeners = false

  @ReactMethod
  fun addListener(_eventName: String) {
    listenerCount++
  }

  @ReactMethod
  fun removeListeners(count: Int) {
    listenerCount -= count
  }

  private fun sendEvent(
    reactContext: ReactApplicationContext,
    eventName: String,
    params: Any?
  ) {
    reactContext
      .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
      .emit(eventName, params)
  }

  override fun capturDidGenerateEvent(state: CapturCameraState, metadata: CapturOutput?) {
    sendEvent(reactContext, EventNames.CapturDidGenerateEvent.rawValue, metadata)
  }

  override fun capturDidGenerateGuidance(metadata: CapturOutput) {
    if (hasListeners) {
      sendEvent(reactContext, EventNames.CapturDidGenerateGuidance.rawValue, metadata)
    }
  }

  override fun capturDidGenerateError(error: CapturError) {
    sendEvent(reactContext, EventNames.CapturDidGenerateError.rawValue, error.errorType)
  }

  companion object {
    operator fun invoke(
      reactContext: ReactApplicationContext,
      callback: (CapturEvents) -> Unit
    ) {
      val instance = CapturReactNativeEventsModule(reactContext)
      callback(instance)
    }
  }

  @ReactMethod
  fun setApiKey(apiKey: String, baseUrl: String?, promise: Promise) {
    try {
      Captur.init(reactContext, apiKey, baseUrl)
      promise.resolve(true)
    } catch (e: Exception) {
      promise.reject("set_timeout_failed", e)
    }
  }

  @ReactMethod
  fun prepareModel(
    locationName: String,
    assetType: String,
    latitude: Double?,
    longitude: Double?,
    promise: Promise
  ) {
    val parsedAssetType = CapturAssetType.entries.firstOrNull { it.value == assetType }
    if (parsedAssetType != null) {
      Captur.prepareModel(locationName, parsedAssetType, latitude, longitude) { result, capturError ->
        if (result) {
          promise.resolve(true)
        } else {
          if (capturError != null) {
            promise.reject("prepare_model_failure", capturError)
          } else {
            promise.reject("prepare_model_failure", "unknown_error")
          }
        }
      }
    }
  }

  @ReactMethod
  fun getConfig(
    locationName: String,
    assetType: String,
    latitude: Double?,
    longitude: Double?,
    promise: Promise
  ) {
    val parsedAssetType = CapturAssetType.entries.firstOrNull { it.value == assetType }
    if (parsedAssetType != null) {
      Captur.getConfig(locationName, parsedAssetType, latitude, longitude) { result, capturError ->
        if (result) {
          promise.resolve(true)
        } else {
          if (capturError != null) {
            promise.reject("get_config_failure", capturError)
          } else {
            promise.reject("get_config_failure", "unknown_error")
          }
        }
      }
    } else {
      promise.reject("invalid_asset_type", AssetParseError.InvalidValue)
    }
  }

  @ReactMethod
  fun setTimeout(timeout: Int, promise: Promise) {
    try {
      Captur.setTimeout(timeout)
      promise.resolve(true)
    } catch (e: Exception) {
      promise.reject("set_timeout_failed", e)
    }
  }

  @ReactMethod
  fun endAttempt(promise: Promise) {
    try {
      val manager = ActiveCameraManager.instance
      if (manager != null) {
        manager.endAttempt()
        promise.resolve(true)
      } else {
        promise.reject("end_attempt_failed", "No active camera manager available")
      }
    } catch (e: Exception) {
      promise.reject("end_attempt_failed", e)
    }
  }

  @ReactMethod
  fun retake(promise: Promise) {
    try {
      val manager = ActiveCameraManager.instance
      if (manager != null) {
        manager.retake()
        promise.resolve(true)
      } else {
        promise.reject("retake_failed", "No active camera manager available")
      }
    } catch (e: Exception) {
      promise.reject("retake_failed", e)
    }
  }


  @ReactMethod
  fun setDelay(delay: Int, promise: Promise) {
    try {
      Captur.setDelay(delay)
      promise.resolve(true)
    } catch (e: Exception) {
      promise.reject("set_delay_failed", e)
    }
  }


  enum class EventNames(val rawValue: String) {
    CapturDidGenerateEvent("capturDidGenerateEvent"),
    CapturDidGenerateError("capturDidGenerateError"),
    CapturDidGenerateGuidance("capturDidGenerateGuidance"),
    CapturDidRevokeGuidance("capturDidRevokeGuidance")
  }
}

sealed class AssetParseError(message: String) : Exception(message) {
  data object InvalidValue : AssetParseError("Invalid value") {
    private fun readResolve(): Any = InvalidValue
  }
}
