package com.capturreactnativeevents

import android.graphics.Bitmap
import android.util.Base64
import com.captur.capturmicromobility.pblic.error.CapturError
import com.captur.capturmicromobility.pblic.events.CapturEvents
import com.captur.capturmicromobility.pblic.models.CapturCameraState
import com.captur.capturmicromobility.pblic.models.CapturOutput
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.WritableMap
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.facebook.react.uimanager.ThemedReactContext
import java.io.ByteArrayOutputStream

/**
 * Subscribes to events from CapturCameraManager and forwards them
 * as React Native events.
 */
class CapturEventListeners(private val reactContext: ThemedReactContext) : CapturEvents {

  override fun capturDidGenerateError(error: CapturError) {
    sendEvent("capturDidGenerateError", Arguments.createMap().apply {
      putString("message", error.message)
    })
  }

  override fun capturDidGenerateEvent(state: CapturCameraState, metadata: CapturOutput?) {
    val body: WritableMap = Arguments.createMap()
    body.putString("state", cameraStateAsString(state))

    metadata?.let {
      body.putMap("metadata", convertOutputToMap(it))
    }

    when (state) {
      CapturCameraState.CAMERA_RUNNING -> {
        sendEvent("capturDidGenerateEvent", body)
      }

      CapturCameraState.CAMERA_DECIDED -> {
        metadata?.let {
          val decision = it.decision
          it.decision = decision
          sendEvent("capturDidGenerateEvent", body)
        }
      }
    }
  }

  override fun capturDidGenerateGuidance(metadata: CapturOutput) {
    val body = convertOutputToMap(metadata)
    sendEvent("capturDidGenerateGuidance", body)
  }

  /**
   * Sends an event to React Native’s JavaScript side.
   */
  private fun sendEvent(eventName: String, params: WritableMap?) {
    reactContext
      .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
      .emit(eventName, params)
  }

  /**
   * Converts a [CapturOutput] object to a [WritableMap].
   */
  private fun convertOutputToMap(metadata: CapturOutput?): WritableMap {
    return Arguments.createMap().apply {
      putString("decision", metadata?.decision.toString())
      putString("reason", metadata?.reason.toString())
      putString("guidanceTitle", metadata?.guidanceTitle.toString())
      putString("guidanceDetail", metadata?.guidanceDetail.toString())
      putString("decisionTitle", metadata?.decisionTitle.toString())
      putString("decisionDetail", metadata?.decisionDetail.toString())
      val imageDataBase64 = metadata?.image?.let { bitmapToBase64(it) } ?: "undefined"
      putString("imageDataBase64", imageDataBase64)
    }
  }

  private fun cameraStateAsString(state: CapturCameraState): String {
    return when (state) {
      CapturCameraState.CAMERA_DECIDED -> "cameraDecided"
      CapturCameraState.CAMERA_RUNNING -> "cameraRunning"
      else -> "cameraError"
    }
  }

  /**
   * Converts a [Bitmap] to a Base64-encoded string.
   */
  private fun bitmapToBase64(bitmap: Bitmap): String {
    val outputStream = ByteArrayOutputStream()
    bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
    val byteArray = outputStream.toByteArray()
    return Base64.encodeToString(byteArray, Base64.NO_WRAP)
  }
}
