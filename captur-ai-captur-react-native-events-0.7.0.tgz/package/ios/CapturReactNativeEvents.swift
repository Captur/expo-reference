import Foundation
import CapturMicromobilityEvents

@objc(CapturReactNativeEvents)
class CapturReactNativeEvents: RCTEventEmitter, CapturEvents {
  var hasListeners: Bool = false

  static var shared: CapturReactNativeEvents?

  @objc(multiply:withB:resolver:rejecter:)
  func multiply(a: Float, b: Float, resolve: RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
    resolve(a*b)
  }

  @objc(endAttempt)
  func endAttempt() -> Void {
    CapturCameraManagerFactory.endAttempt()
  }
  
  @objc(retake)
  func retake() -> Void {
    CapturCameraManagerFactory.retake()
  }
  
  
  @objc(setDelay:resolver:rejecter:)
  func setDelay(delay: Int, resolve: RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
    print("Setting delay to \(delay) seconds")
    do {
      try Captur.shared.setDelay(value: delay)
      resolve(true)
    } catch {
      reject("set_delay_failed", error.localizedDescription, error)
    }
  }
  
  @objc(setTimeout:resolver:rejecter:)
  func setTimeout(timeout: Int, resolve: RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
    print("Setting timeout to \(timeout) seconds")
    do {
      try Captur.shared.setTimeout(value: timeout)
      resolve(true)
    } catch {
      reject("set_timeout_failed", error.localizedDescription, error)
    }
  }

  @objc(setApiKey:baseURL:resolver:rejecter:)
  func setApiKey(apiKey: String, baseURL: String?, resolve: RCTPromiseResolveBlock, reject:RCTPromiseRejectBlock) -> Void {
    CapturReactNativeEvents.shared = self
    do {
      try Captur.shared.setApi(key: apiKey, baseURL: baseURL)
      resolve(true)
    } catch {
      reject("set_api_failed", error.localizedDescription, error)
    }
  }

  @objc(prepareModel:assetType:latitude:longitude:resolver:rejecter:)
  func prepareModel(
    locationName: String,
    assetType: String,
    latitude: Float,
    longitude: Float,
    resolve: @escaping RCTPromiseResolveBlock,
    reject: @escaping RCTPromiseRejectBlock
  ) {

    if let parsedAssetType = CapturAssetType(rawValue: assetType) {
      Captur.shared.prepareModel(locationName: locationName,
                                 assetType: parsedAssetType,
                                 latitude: latitude,
                                 longitude: longitude) { (result: Bool, capturError: CapturError?) -> Void in
        if result {
          resolve(true)
        } else {
          if let capturError = capturError {
            reject("prepare_model_failure", capturError.localizedDescription, capturError)
          } else {
            reject("unknown", FallbackError.unknownError.localizedDescription, FallbackError.unknownError)
          }
        }
      }
    } else {
      let err = AssetParseError.invalidValue
      
      reject("invalid_asset_type", err.localizedDescription, err)
    }
  }

  @objc(getConfig:assetType:latitude:longitude:resolver:rejecter:)
  func getConfig(
    locationName: String,
    assetType: String,
    latitude: Float,
    longitude: Float,
    resolve: @escaping RCTPromiseResolveBlock,
    reject: @escaping RCTPromiseRejectBlock
  ) {

    if let parsedAssetType = CapturAssetType(rawValue: assetType) {
      Captur.shared.getConfig(locationName: locationName,
                              assetType: parsedAssetType,
                              latitude: latitude,
                              longitude: longitude) { (result: Bool, capturError: CapturError?) -> Void in
        if result {
          resolve(true)
        } else {
          if let capturError = capturError {
            reject("get_config_failure", capturError.localizedDescription, capturError)
          } else {
            reject("unknown", FallbackError.unknownError.localizedDescription, FallbackError.unknownError)
          }
        }
      }
    } else {
      let err = AssetParseError.invalidValue

      reject("invalid_asset_type", err.localizedDescription, err)
    }
  }

  override func startObserving() {
    print("startObserving")
    hasListeners = true
  }

  override func stopObserving() {
    print("stopObserving")
    hasListeners = false
  }

  override func supportedEvents() -> [String]! {
    return EventNames.allCases.map { $0.rawValue}
  }

  func capturDidGenerateEvent(state: CapturCameraState, metadata: CapturOutput?) {
    print("capturDidGenerateEvent")
    if hasListeners {
      var body: [String: Any] = ["state" : cameraStateAsString(state: state)]

      if let metadata = metadata {
        body["metadata"] = convertOutputToMap(metadata: metadata)
      }

      print("capturDidGenerateEvent - sendEvent")
      sendEvent(withName: EventNames.capturDidGenerateEvent.rawValue, body: body)
    }
  }

  func capturDidGenerateGuidance(metadata: CapturOutput) {
    print("capturDidGenerateGuidance")
    if hasListeners {
      print("capturDidGenerateEvent - sendEvent")
      sendEvent(withName: EventNames.capturDidGenerateGuidance.rawValue, body: convertOutputToMap(metadata: metadata))
    }
  }

  func capturDidRevokeGuidance() {
    if hasListeners {
      sendEvent(withName: EventNames.capturDidRevokeGuidance.rawValue, body: [:])
    }
  }

  func capturDidGenerateError(error: CapturError) {
    if hasListeners {
      sendEvent(withName: EventNames.capturDidGenerateError.rawValue, body: ["errorType" : errorAsString(error: error.errorType), "errorMessage" : error.errorMessage])
    }
  }

  private func cameraStateAsString(state: CapturCameraState) -> String {
    switch state {
    case .cameraDecided:
      "cameraDecided"
    case .cameraRunning:
      "cameraRunning"
    default:
      "cameraError"
    }
  }

  private func convertOutputToMap(metadata: CapturOutput) -> [String : String] {
    var fieldMap = ["decision" : metadata.decision.rawValue, "reason" : metadata.reason]

    if let guidanceTitle = metadata.guidanceTitle {
      fieldMap["guidanceTitle"] = guidanceTitle
    }

    if let guidanceDetail = metadata.guidanceDetail {
      fieldMap["guidanceDetail"] = guidanceDetail
    }

    if let decisionTitle = metadata.decisionTitle {
      fieldMap["decisionTitle"] = decisionTitle
    }

    if let decisionDetail = metadata.decisionDetail {
      fieldMap["decisionDetail"] = decisionDetail
    }

    if let image = metadata.image, let data = image.pngData() {
      fieldMap["imageDataBase64"] = data.base64EncodedString()
    }

    return fieldMap
  }

  private func errorAsString(error: CapturError.ErrorType) -> String {
    switch error {

    case .locationNameEmpty:
      "locationNameEmpty"

    case .modelInitialisationFailure:
      "modelInitialisationFailure"

    case .modelUnavailable:
      "modelUnavailable"

    case .serialisationError:
      "serialisationError"

    case .modelVerificationFailed:
      "modelVerificationFailed"

    case .serverError:
      "serverError"

    case .videoDeviceNotFound:
      "videoDeviceNotFound"

    case .videoDeviceInputError:
      "videoDeviceInputError"

    case .videoDeviceOutputError:
      "videoDeviceOutputError"

    case .videoDeviceLockError:
      "videoDeviceLockError"

    case .modelDoesNotExistOnDevice:
      "modelDoesNotExistOnDevice"

    case .unknownError:
      "unknownError"

    default:
      "unknownError"
    }
  }
}

enum AssetParseError: Error {
    case invalidValue
}

enum FallbackError: Error {
  case unknownError
}

enum EventNames: String, CaseIterable {
  case capturDidGenerateEvent
  case capturDidGenerateError
  case capturDidGenerateGuidance
  case capturDidRevokeGuidance
}
