#import <React/RCTViewManager.h>

@interface RCT_EXTERN_MODULE(CapturCameraViewManager, RCTViewManager)
RCT_EXPORT_VIEW_PROPERTY(referenceId, NSString)
RCT_EXPORT_VIEW_PROPERTY(isFlashOn, BOOL)
RCT_EXPORT_VIEW_PROPERTY(isZoomedIn, BOOL)
RCT_EXPORT_VIEW_PROPERTY(startVerification, BOOL)
@end
