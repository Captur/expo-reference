import SwiftUI
import CapturMicromobilityEvents

struct CameraView: View {
  @ObservedObject private var cameraViewFields: CameraViewFields
  @State private var capturCameraManager: CapturCameraManager?

  init(cameraViewFields: CameraViewFields) {
    self.cameraViewFields = cameraViewFields
  }
    
  // TODO add ultraWide property here (via CameraViewFields)

  var body: some View {
    ZStack {
      Color.black.edgesIgnoringSafeArea(.all)

      if cameraViewFields.startVerification {
        if let manager = capturCameraManager {
          CapturCamera(
            capturCameraHandler: manager,
            isFlashOn: isFlashOn,
            isZoomedIn: isZoomedIn
          )
        } else {
          Text("Camera manager is nil")
        }
      }
    }
    .onAppear {
      if cameraViewFields.startVerification {
        capturCameraManager = CapturCameraManagerFactory.manager(for: cameraViewFields.referenceId)
      }
    }
    .onChange(of: cameraViewFields.startVerification) { start in
      if start {
        capturCameraManager = CapturCameraManagerFactory.manager(for: cameraViewFields.referenceId)
      } else {
        capturCameraManager?.endAttempt()
      }
    }
    .onChange(of: cameraViewFields.referenceId) { newRef in
      if cameraViewFields.startVerification {
        capturCameraManager = CapturCameraManagerFactory.manager(for: newRef)
      } else {
        capturCameraManager = nil
      }
    }
  }

  private var isFlashOn: Binding<Bool> {
    Binding(
      get: { cameraViewFields.isFlashOn },
      set: { cameraViewFields.isFlashOn = $0 }
    )
  }

  private var isZoomedIn: Binding<Bool> {
    Binding(
      get: { cameraViewFields.isZoomedIn },
      set: { cameraViewFields.isZoomedIn = $0 }
    )
  }
}

