import Foundation
import CapturMicromobilityEvents

enum CapturCameraManagerStatus: String {
  case newReference
  case retryReference
}

class CapturCameraManagerFactory: NSObject {
  private var capturCameraManager: CapturCameraManager?
  private var activeReferenceId: String?

  public static let shared = CapturCameraManagerFactory()

  public static func manager(for referenceId: String) -> CapturCameraManager {
    let factory = shared

    if factory.capturCameraManager == nil
       || factory.activeReferenceId != referenceId
    {
      print("Creating CapturCameraManager for ref: \(referenceId)")

      if let oldMgr = factory.capturCameraManager {
        oldMgr.endAttempt()
      }


      let newMgr = CapturCameraManager(referenceId: referenceId)
      if let events = CapturReactNativeEvents.shared {
        newMgr.subscribeToEvents(events: events)
      }
      factory.capturCameraManager = newMgr
      factory.activeReferenceId = referenceId
    } else {
      print("Reusing existing CapturCameraManager for ref: \(referenceId)")
    }

    return factory.capturCameraManager!
  }

  @objc public static func endAttempt() {
    if let mgr = shared.capturCameraManager {
      mgr.endAttempt()
    } else {
      print("No active manager to endAttempt")
    }
  }

  @objc public static func retake() {
    if let mgr = shared.capturCameraManager {
      mgr.retake()
    } else {
      print("No active manager to retake")
    }
  }
}

class DummyEvents: CapturEvents {
  func capturDidGenerateEvent(state: CapturMicromobilityEvents.CapturCameraState, metadata: CapturMicromobilityEvents.CapturOutput?) {
    print("called dummy capturDidGenerateEvent")
  }

  func capturDidGenerateError(error: CapturMicromobilityEvents.CapturError) {
    print("called dummy capturDidGenerateError")
  }

  func capturDidGenerateGuidance(metadata: CapturMicromobilityEvents.CapturOutput) {
    print("called dummy capturDidGenerateGuidance")
  }

  func capturDidRevokeGuidance() {
    print("called dummy capturDidRevokeGuidance")
  }
}
