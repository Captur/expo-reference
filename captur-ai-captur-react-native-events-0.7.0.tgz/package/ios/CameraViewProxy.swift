import UIKit
import SwiftUI

class CameraViewFields: ObservableObject {
  @Published var isFlashOn: Bool = false
  @Published var isZoomedIn: Bool = false
  @Published var referenceId: String = "123456"
  @Published var startVerification: Bool = false
}

class CameraViewProxy: UIView {

  var returningView: UIView?
  @ObservedObject var cameraViewFields: CameraViewFields = CameraViewFields()
  
  override init(frame: CGRect) {
    super.init(frame: frame)

    let vc = UIHostingController(
      rootView: CameraView(cameraViewFields: cameraViewFields)
    )
    vc.view.frame = bounds
    self.addSubview(vc.view)
    self.returningView = vc.view
  }

  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }

  override func layoutSubviews() {
    super.layoutSubviews()
    self.returningView?.frame = bounds
  }

  @objc var isFlashOn: Bool = false {
    didSet {
      cameraViewFields.isFlashOn = isFlashOn
    }
  }
  
  @objc var isZoomedIn: Bool = false {
    didSet {
      cameraViewFields.isZoomedIn = isZoomedIn
    }
  }
  
  @objc var referenceId: String = "" {
    didSet {
      cameraViewFields.referenceId = referenceId
    }
  }

  @objc var startVerification: Bool = false {
    didSet {
      cameraViewFields.startVerification = startVerification
    }
  }
}

