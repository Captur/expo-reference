import Foundation
import CapturMicromobilityEvents
import SwiftUI

@objc(CapturCameraViewManager)
class CapturCameraViewManager: RCTViewManager {

  override static func requiresMainQueueSetup() -> Bool {
    return true
  }

  override func view() -> UIView! {
    return CameraViewProxy()
  }
}


