import { type HostComponent, type ViewStyle } from 'react-native';
export type CapturDecision = 'goodDelivery' | 'improvableDelivery' | 'badDelivery' | 'insufficientInformation' | 'noDecisionMapDetected';
export type CapturCameraState = 'cameraRunning' | 'cameraDecided' | 'cameraError';
export interface CapturOutput {
    decision: CapturDecision;
    reason: string;
    guidanceTitle: string | undefined;
    guidanceDetail: string | undefined;
    decisionTitle: string | undefined;
    decisionDetail: string | undefined;
    imageDataBase64: string | undefined;
}
export type CapturErrorType = 'locationNameEmpty' | 'modelInitialisationFailure' | 'modelUnavailable' | 'serialisationError' | 'modelVerificationFailed' | 'serverError' | 'videoDeviceNotFound' | 'videoDeviceInputError' | 'videoDeviceOutputError' | 'videoDeviceLockError' | 'modelDoesNotExistOnDevice' | 'unknownError';
export interface CapturError {
    errorType: CapturErrorType;
    errorMessage: string;
}
export declare enum CapturEventHandlerType {
    capturDidGenerateEvent = "capturDidGenerateEvent",
    capturDidGenerateError = "capturDidGenerateError",
    capturDidGenerateGuidance = "capturDidGenerateGuidance",
    capturDidRevokeGuidance = "capturDidRevokeGuidance"
}
export interface CapturEventsHandler {
    capturDidGenerateEvent: (capturCameraState: CapturCameraState, metadata: CapturOutput | undefined) => void;
    capturDidGenerateError: (capturError: CapturError) => void;
    capturDidGenerateGuidance: (metadata: CapturOutput) => void;
    capturDidRevokeGuidance: () => void;
}
export declare function subscribeToEvents(capturEventsHandler: CapturEventsHandler): () => void;
export declare function endAttempt(): any;
export declare function retake(): any;
export declare function setDelay(delay: number): Promise<boolean>;
export declare function setTimeout(timeout: number): Promise<boolean>;
export declare function setApiKey(apiKey: string, baseURL?: string | null): Promise<boolean>;
export declare function prepareModel(locationName: string, assetType: string, latitude: number, longitude: number): Promise<boolean>;
export declare function getConfig(locationName: string, assetType: string, latitude: number, longitude: number): Promise<boolean>;
type CapturCameraViewProps = {
    style: ViewStyle;
    referenceId: string;
    isFlashOn: boolean;
    isZoomedIn: boolean;
    startVerification: boolean;
};
export declare const CapturCameraView: HostComponent<CapturCameraViewProps>;
export {};
//# sourceMappingURL=index.d.ts.map